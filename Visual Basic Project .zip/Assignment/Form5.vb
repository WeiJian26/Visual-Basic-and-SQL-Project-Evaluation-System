﻿Imports System.Data.OleDb
Public Class Form5
    Public strUserID As String = ""
    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("Welcome " & strUserID)
        loadComboBox()
    End Sub
    Private Sub loadComboBox()
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "SELECT courseName FROM CourseTable"
                Try
                    cn.Open()
                    cmd.Connection = cn
                    Dim dr As OleDbDataReader = cmd.ExecuteReader
                    While dr.Read
                        cboCourseName.Items.Add(dr.Item("courseName"))
                    End While
                    cn.Close()
                Catch ex As Exception

                End Try
            End Using
        End Using
    End Sub

    Private Sub cboCourseName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCourseName.SelectedIndexChanged
        Dim cn As New OleDbConnection(ConnectionString)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT * FROM CourseTable WHERE CourseName = ?"
        Try
            cn.Open()
            cmd.Parameters.AddWithValue("?", cboCourseName.SelectedItem)
            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                lblCourseID.Text = dr.Item("courseID")
                lblLecturerID.Text = dr.Item("lecturerID")


            End If
            cn.Close()
        Catch ex As Exception
            MessageBox.Show("aaa" & ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        loadDatabaseTable()
    End Sub
    Private Sub loadDatabaseTable()
        Dim strStudentID As String = ""
        Dim strCourseName As String = ""
        Dim strCourseID As String = ""
        Dim strLecturerID As String = ""
        Dim intNoCancellationClass As Integer = 0
        Dim intKeepsOnSchedule As Integer = 0
        Dim intCaringAndLoving As Integer = 0
        Dim intFriendly As Integer = 0
        Dim intGoodCommunication As Integer = 0
        Dim intOrganizationSkills As Integer = 0
        Dim intExcellentPreparation As Integer = 0
        Dim intDeepKnowledgeAndPassion As Integer = 0
        Dim dblAverageMarks As Double = 0.0
        Dim intTotalMarks As Integer = 0

        strStudentID = strUserID
        strCourseName = cboCourseName.SelectedItem
        strCourseID = lblCourseID.Text
        strLecturerID = lblLecturerID.Text

        If rad1.Checked = True Then
            intNoCancellationClass = 1
        ElseIf rad2.Checked = True Then
            intNoCancellationClass = 2
        ElseIf rad3.Checked = True Then
            intNoCancellationClass = 3
        ElseIf rad4.Checked = True Then
            intNoCancellationClass = 4
        ElseIf rad5.Checked = True Then
            intNoCancellationClass = 5
        End If

        If rad6.Checked = True Then
            intKeepsOnSchedule = 1
        ElseIf rad8.Checked = True Then
            intKeepsOnSchedule = 2
        ElseIf rad7.Checked = True Then
            intKeepsOnSchedule = 3
        ElseIf rad9.Checked = True Then
            intKeepsOnSchedule = 4
        ElseIf rad10.Checked = True Then
            intKeepsOnSchedule = 5
        End If

        If rad11.Checked = True Then
            intCaringAndLoving = 1
        ElseIf rad12.Checked = True Then
            intCaringAndLoving = 2
        ElseIf rad13.Checked = True Then
            intCaringAndLoving = 3
        ElseIf rad14.Checked = True Then
            intCaringAndLoving = 4
        ElseIf rad15.Checked = True Then
            intCaringAndLoving = 5
        End If

        If rad16.Checked = True Then
            intFriendly = 1
        ElseIf rad17.Checked = True Then
            intFriendly = 2
        ElseIf rad18.Checked = True Then
            intFriendly = 3
        ElseIf rad19.Checked = True Then
            intFriendly = 4
        ElseIf rad20.Checked = True Then
            intFriendly = 5
        End If

        If rad21.Checked = True Then
            intGoodCommunication = 1
        ElseIf rad22.Checked = True Then
            intGoodCommunication = 2
        ElseIf rad23.Checked = True Then
            intGoodCommunication = 3
        ElseIf rad24.Checked = True Then
            intGoodCommunication = 4
        ElseIf rad25.Checked = True Then
            intGoodCommunication = 5
        End If

        If rad26.Checked = True Then
            intOrganizationSkills = 1
        ElseIf rad27.Checked = True Then
            intOrganizationSkills = 2
        ElseIf rad28.Checked = True Then
            intOrganizationSkills = 3
        ElseIf rad29.Checked = True Then
            intOrganizationSkills = 4
        ElseIf rad30.Checked = True Then
            intOrganizationSkills = 5
        End If

        If rad31.Checked = True Then
            intExcellentPreparation = 1
        ElseIf rad32.Checked = True Then
            intExcellentPreparation = 2
        ElseIf rad33.Checked = True Then
            intExcellentPreparation = 3
        ElseIf rad34.Checked = True Then
            intExcellentPreparation = 4
        ElseIf rad35.Checked = True Then
            intExcellentPreparation = 5
        End If

        If rad36.Checked = True Then
            intDeepKnowledgeAndPassion = 1
        ElseIf rad37.Checked = True Then
            intDeepKnowledgeAndPassion = 2
        ElseIf rad38.Checked = True Then
            intDeepKnowledgeAndPassion = 3
        ElseIf rad39.Checked = True Then
            intDeepKnowledgeAndPassion = 4
        ElseIf rad40.Checked = True Then
            intDeepKnowledgeAndPassion = 5
        End If

        dblAverageMarks = (intNoCancellationClass + intKeepsOnSchedule + intCaringAndLoving + intFriendly + intGoodCommunication + intOrganizationSkills + intExcellentPreparation + intDeepKnowledgeAndPassion) / 8
        intTotalMarks = intNoCancellationClass + intKeepsOnSchedule + intCaringAndLoving + intFriendly + intGoodCommunication + intOrganizationSkills + intExcellentPreparation + intDeepKnowledgeAndPassion

        Dim cn As New OleDbConnection(ConnectionString)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "INSERT INTO EvaluationTable(nocancellationclass,keepsonschedule,caringandloving,friendly,goodcommunication,organizationskills,excellentpreparation,deepknowledgeandpassion,averageMarks,totalMarks,courseName,courseID,lecturerID,studentID)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        cmd.Parameters.AddWithValue("?", intNoCancellationClass)
        cmd.Parameters.AddWithValue("?", intKeepsOnSchedule)
        cmd.Parameters.AddWithValue("?", intCaringAndLoving)
        cmd.Parameters.AddWithValue("?", intFriendly)
        cmd.Parameters.AddWithValue("?", intGoodCommunication)
        cmd.Parameters.AddWithValue("?", intOrganizationSkills)
        cmd.Parameters.AddWithValue("?", intExcellentPreparation)
        cmd.Parameters.AddWithValue("?", intDeepKnowledgeAndPassion)
        cmd.Parameters.AddWithValue("?", dblAverageMarks)
        cmd.Parameters.AddWithValue("?", intTotalMarks)
        cmd.Parameters.AddWithValue("?", strCourseName)
        cmd.Parameters.AddWithValue("?", strCourseID)
        cmd.Parameters.AddWithValue("?", strLecturerID)
        cmd.Parameters.AddWithValue("?", strStudentID)


        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            MessageBox.Show("Submit sucessfully!")
        Catch ex As Exception
            MessageBox.Show("Error" & ex.ToString)

        End Try

        rad1.Checked = False
        rad2.Checked = False
        rad3.Checked = False
        rad4.Checked = False
        rad5.Checked = False

        rad6.Checked = False
        rad7.Checked = False
        rad8.Checked = False
        rad9.Checked = False
        rad10.Checked = False

        rad11.Checked = False
        rad12.Checked = False
        rad13.Checked = False
        rad14.Checked = False
        rad15.Checked = False

        rad16.Checked = False
        rad17.Checked = False
        rad18.Checked = False
        rad19.Checked = False
        rad20.Checked = False

        rad21.Checked = False
        rad22.Checked = False
        rad23.Checked = False
        rad24.Checked = False
        rad25.Checked = False

        rad26.Checked = False
        rad27.Checked = False
        rad28.Checked = False
        rad29.Checked = False
        rad30.Checked = False

        rad31.Checked = False
        rad32.Checked = False
        rad33.Checked = False
        rad34.Checked = False
        rad35.Checked = False

        rad36.Checked = False
        rad37.Checked = False
        rad38.Checked = False
        rad39.Checked = False
        rad40.Checked = False

        lblCourseID.Text = ""
        lblLecturerID.Text = ""
        cboCourseName.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
        Dim Form4 As New Form4
        Form4.Show()
    End Sub
End Class