﻿Imports System.Data.OleDb
Public Class Form7
    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDatabaseTable()
    End Sub
    Public Sub loadDatabaseTable()
        Dim cn As New OleDbConnection(ConnectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
        cmd.CommandText = "SELECT MIN(totalMarks) As 'Lowest Total(out of 40)' , MAX(totalMarks) As 'Highest Total(out of 40)', 
        AVG(totalMarks) As 'Average Total(out of 40)' , courseID FROM EvaluationTable GROUP BY courseID;" 'giving SQL Command
        Dim dt As New DataTable With {.TableName = "EvaluationTable"} 'create new table in Visual Studio

        Try
            cn.Open()
            Dim ds As New DataSet
            Dim assignmentTable As New DataTable With {.TableName = "EvaluationTable"}
            ds.Tables.Add(assignmentTable)
            ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, assignmentTable)

            DataGridView1.DataSource = ds.Tables("EvaluationTable")
            'DataGridView1.Columns("course").Visible = False

            cn.Close()

        Catch ex As Exception

            'very common for a developer to simply ignore errors,unwise
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class