﻿Imports System.Data.OleDb
Public Class Form6
    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBox()
        loadDatabaseTable()
    End Sub
    Private Sub loadComboBox()
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "SELECT evaluationID FROM EvaluationTable"
                Try
                    cn.Open()
                    cmd.Connection = cn
                    Dim dr As OleDbDataReader = cmd.ExecuteReader
                    While dr.Read
                        cboEvaluationID.Items.Add(dr.Item("evaluationID"))
                    End While
                    cn.Close()
                Catch ex As Exception

                End Try
            End Using
        End Using
    End Sub
    Private Sub loadDatabaseTable()
        Dim cn As New OleDbConnection(ConnectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
        cmd.CommandText = "SELECT MIN(averageMarks) As 'Minimum Mark' , MAX(averageMarks) As 'Maximum Mark', 
        AVG(averageMarks) As 'Average Mark' , evaluationID FROM EvaluationTable GROUP BY evaluationID;" 'giving SQL Command
        Dim dt As New DataTable With {.TableName = "EvaluationTable"} 'create new table in Visual Studio

        Try
            cn.Open()
            Dim ds As New DataSet
            Dim assignmentTable As New DataTable With {.TableName = "EvaluationTable"}
            ds.Tables.Add(assignmentTable)
            ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, assignmentTable)

            DataGridView1.DataSource = ds.Tables("EvaluationTable")
            'DataGridView1.Columns("EmpID").Visible = False

            cn.Close()

        Catch ex As Exception

            'very common for a developer to simply ignore errors,unwise
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub cboEvaluationID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboEvaluationID.SelectedIndexChanged
        Dim cn As New OleDbConnection(ConnectionString)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT * FROM EvaluationTable WHERE evaluationID = ?"
        Try
            cn.Open()
            cmd.Parameters.AddWithValue("?", cboEvaluationID.SelectedItem)
            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                lblAverageMarks.Text = dr.Item("averageMarks")
                lblMinMarks.Text = dr.Item("averageMarks")
                lblMaxMarks.Text = dr.Item("averageMarks")

            End If
            cn.Close()
        Catch ex As Exception
            MessageBox.Show("aaa" & ex.ToString)
        End Try
    End Sub

End Class