﻿Imports System.Data.OleDb
Public Class Form4

    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"


    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        Dim cn As New OleDbConnection(ConnectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
        cmd.CommandText = "SELECT * FROM StudentTable WHERE studentID=? AND studentPassword=?;" 'giving SQL Command

        If txtUsername.Text = "Admin" And txtPassword.Text = "admin" Then
            Dim Form1 As New Form1
            Form1.Show()
            Me.Hide()
        Else
            Try
                cn.Open()
                cmd.Parameters.AddWithValue("?", txtUsername.Text)
                cmd.Parameters.AddWithValue("?", txtPassword.Text)
                cmd.Connection = cn
                Dim dr As OleDbDataReader = cmd.ExecuteReader
                If dr.Read Then
                    Dim Form5 As New Form5
                    Form5.strUserID = txtUsername.Text
                    Form5.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Invalid username and password")
                End If
                cn.Close()
            Catch ex As Exception
                'very common for a developer to simply ignore errors,unwise
            End Try
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Application.Exit()
        'Me.Close()
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class