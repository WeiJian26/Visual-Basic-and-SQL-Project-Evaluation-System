﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboCourseName = New System.Windows.Forms.ComboBox()
        Me.lblCourseID = New System.Windows.Forms.Label()
        Me.lblLecturerID = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rad5 = New System.Windows.Forms.RadioButton()
        Me.rad2 = New System.Windows.Forms.RadioButton()
        Me.rad3 = New System.Windows.Forms.RadioButton()
        Me.rad1 = New System.Windows.Forms.RadioButton()
        Me.rad4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rad10 = New System.Windows.Forms.RadioButton()
        Me.rad7 = New System.Windows.Forms.RadioButton()
        Me.rad8 = New System.Windows.Forms.RadioButton()
        Me.rad9 = New System.Windows.Forms.RadioButton()
        Me.rad6 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rad15 = New System.Windows.Forms.RadioButton()
        Me.rad14 = New System.Windows.Forms.RadioButton()
        Me.rad12 = New System.Windows.Forms.RadioButton()
        Me.rad11 = New System.Windows.Forms.RadioButton()
        Me.rad13 = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rad20 = New System.Windows.Forms.RadioButton()
        Me.rad19 = New System.Windows.Forms.RadioButton()
        Me.rad17 = New System.Windows.Forms.RadioButton()
        Me.rad16 = New System.Windows.Forms.RadioButton()
        Me.rad18 = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.rad25 = New System.Windows.Forms.RadioButton()
        Me.rad23 = New System.Windows.Forms.RadioButton()
        Me.rad21 = New System.Windows.Forms.RadioButton()
        Me.rad22 = New System.Windows.Forms.RadioButton()
        Me.rad24 = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rad30 = New System.Windows.Forms.RadioButton()
        Me.rad29 = New System.Windows.Forms.RadioButton()
        Me.rad26 = New System.Windows.Forms.RadioButton()
        Me.rad28 = New System.Windows.Forms.RadioButton()
        Me.rad27 = New System.Windows.Forms.RadioButton()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.rad35 = New System.Windows.Forms.RadioButton()
        Me.rad34 = New System.Windows.Forms.RadioButton()
        Me.rad31 = New System.Windows.Forms.RadioButton()
        Me.rad33 = New System.Windows.Forms.RadioButton()
        Me.rad32 = New System.Windows.Forms.RadioButton()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.rad40 = New System.Windows.Forms.RadioButton()
        Me.rad38 = New System.Windows.Forms.RadioButton()
        Me.rad39 = New System.Windows.Forms.RadioButton()
        Me.rad36 = New System.Windows.Forms.RadioButton()
        Me.rad37 = New System.Windows.Forms.RadioButton()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Course ID:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Lecturer ID:"
        '
        'cboCourseName
        '
        Me.cboCourseName.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCourseName.FormattingEnabled = True
        Me.cboCourseName.Location = New System.Drawing.Point(187, 29)
        Me.cboCourseName.Name = "cboCourseName"
        Me.cboCourseName.Size = New System.Drawing.Size(309, 31)
        Me.cboCourseName.TabIndex = 3
        '
        'lblCourseID
        '
        Me.lblCourseID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourseID.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourseID.Location = New System.Drawing.Point(187, 80)
        Me.lblCourseID.Name = "lblCourseID"
        Me.lblCourseID.Size = New System.Drawing.Size(309, 33)
        Me.lblCourseID.TabIndex = 4
        '
        'lblLecturerID
        '
        Me.lblLecturerID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLecturerID.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLecturerID.Location = New System.Drawing.Point(187, 130)
        Me.lblLecturerID.Name = "lblLecturerID"
        Me.lblLecturerID.Size = New System.Drawing.Size(309, 30)
        Me.lblLecturerID.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rad5)
        Me.GroupBox1.Controls.Add(Me.rad2)
        Me.GroupBox1.Controls.Add(Me.rad3)
        Me.GroupBox1.Controls.Add(Me.rad1)
        Me.GroupBox1.Controls.Add(Me.rad4)
        Me.GroupBox1.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(102, 210)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "1. No Cancellation Class"
        '
        'rad5
        '
        Me.rad5.AutoSize = True
        Me.rad5.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad5.Location = New System.Drawing.Point(438, 36)
        Me.rad5.Name = "rad5"
        Me.rad5.Size = New System.Drawing.Size(41, 25)
        Me.rad5.TabIndex = 14
        Me.rad5.TabStop = True
        Me.rad5.Text = "5"
        Me.rad5.UseVisualStyleBackColor = True
        '
        'rad2
        '
        Me.rad2.AutoSize = True
        Me.rad2.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad2.Location = New System.Drawing.Point(230, 36)
        Me.rad2.Name = "rad2"
        Me.rad2.Size = New System.Drawing.Size(41, 25)
        Me.rad2.TabIndex = 11
        Me.rad2.TabStop = True
        Me.rad2.Text = "2"
        Me.rad2.UseVisualStyleBackColor = True
        '
        'rad3
        '
        Me.rad3.AutoSize = True
        Me.rad3.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad3.Location = New System.Drawing.Point(300, 36)
        Me.rad3.Name = "rad3"
        Me.rad3.Size = New System.Drawing.Size(41, 25)
        Me.rad3.TabIndex = 12
        Me.rad3.TabStop = True
        Me.rad3.Text = "3"
        Me.rad3.UseVisualStyleBackColor = True
        '
        'rad1
        '
        Me.rad1.AutoSize = True
        Me.rad1.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad1.Location = New System.Drawing.Point(152, 36)
        Me.rad1.Name = "rad1"
        Me.rad1.Size = New System.Drawing.Size(41, 25)
        Me.rad1.TabIndex = 10
        Me.rad1.TabStop = True
        Me.rad1.Text = "1"
        Me.rad1.UseVisualStyleBackColor = True
        '
        'rad4
        '
        Me.rad4.AutoSize = True
        Me.rad4.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad4.Location = New System.Drawing.Point(370, 36)
        Me.rad4.Name = "rad4"
        Me.rad4.Size = New System.Drawing.Size(41, 25)
        Me.rad4.TabIndex = 13
        Me.rad4.TabStop = True
        Me.rad4.Text = "4"
        Me.rad4.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rad10)
        Me.GroupBox2.Controls.Add(Me.rad7)
        Me.GroupBox2.Controls.Add(Me.rad8)
        Me.GroupBox2.Controls.Add(Me.rad9)
        Me.GroupBox2.Controls.Add(Me.rad6)
        Me.GroupBox2.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(102, 279)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "2. Keeps On Schedule"
        '
        'rad10
        '
        Me.rad10.AutoSize = True
        Me.rad10.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad10.Location = New System.Drawing.Point(438, 36)
        Me.rad10.Name = "rad10"
        Me.rad10.Size = New System.Drawing.Size(41, 25)
        Me.rad10.TabIndex = 19
        Me.rad10.TabStop = True
        Me.rad10.Text = "5"
        Me.rad10.UseVisualStyleBackColor = True
        '
        'rad7
        '
        Me.rad7.AutoSize = True
        Me.rad7.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad7.Location = New System.Drawing.Point(230, 36)
        Me.rad7.Name = "rad7"
        Me.rad7.Size = New System.Drawing.Size(41, 25)
        Me.rad7.TabIndex = 16
        Me.rad7.TabStop = True
        Me.rad7.Text = "2"
        Me.rad7.UseVisualStyleBackColor = True
        '
        'rad8
        '
        Me.rad8.AutoSize = True
        Me.rad8.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad8.Location = New System.Drawing.Point(300, 36)
        Me.rad8.Name = "rad8"
        Me.rad8.Size = New System.Drawing.Size(41, 25)
        Me.rad8.TabIndex = 17
        Me.rad8.TabStop = True
        Me.rad8.Text = "3"
        Me.rad8.UseVisualStyleBackColor = True
        '
        'rad9
        '
        Me.rad9.AutoSize = True
        Me.rad9.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad9.Location = New System.Drawing.Point(370, 36)
        Me.rad9.Name = "rad9"
        Me.rad9.Size = New System.Drawing.Size(41, 25)
        Me.rad9.TabIndex = 18
        Me.rad9.TabStop = True
        Me.rad9.Text = "4"
        Me.rad9.UseVisualStyleBackColor = True
        '
        'rad6
        '
        Me.rad6.AutoSize = True
        Me.rad6.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad6.Location = New System.Drawing.Point(152, 36)
        Me.rad6.Name = "rad6"
        Me.rad6.Size = New System.Drawing.Size(41, 25)
        Me.rad6.TabIndex = 15
        Me.rad6.TabStop = True
        Me.rad6.Text = "1"
        Me.rad6.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rad15)
        Me.GroupBox3.Controls.Add(Me.rad14)
        Me.GroupBox3.Controls.Add(Me.rad12)
        Me.GroupBox3.Controls.Add(Me.rad11)
        Me.GroupBox3.Controls.Add(Me.rad13)
        Me.GroupBox3.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(102, 348)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "3. Caring And Loving"
        '
        'rad15
        '
        Me.rad15.AutoSize = True
        Me.rad15.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad15.Location = New System.Drawing.Point(438, 36)
        Me.rad15.Name = "rad15"
        Me.rad15.Size = New System.Drawing.Size(41, 25)
        Me.rad15.TabIndex = 19
        Me.rad15.TabStop = True
        Me.rad15.Text = "5"
        Me.rad15.UseVisualStyleBackColor = True
        '
        'rad14
        '
        Me.rad14.AutoSize = True
        Me.rad14.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad14.Location = New System.Drawing.Point(370, 36)
        Me.rad14.Name = "rad14"
        Me.rad14.Size = New System.Drawing.Size(41, 25)
        Me.rad14.TabIndex = 18
        Me.rad14.TabStop = True
        Me.rad14.Text = "4"
        Me.rad14.UseVisualStyleBackColor = True
        '
        'rad12
        '
        Me.rad12.AutoSize = True
        Me.rad12.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad12.Location = New System.Drawing.Point(230, 36)
        Me.rad12.Name = "rad12"
        Me.rad12.Size = New System.Drawing.Size(41, 25)
        Me.rad12.TabIndex = 16
        Me.rad12.TabStop = True
        Me.rad12.Text = "2"
        Me.rad12.UseVisualStyleBackColor = True
        '
        'rad11
        '
        Me.rad11.AutoSize = True
        Me.rad11.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad11.Location = New System.Drawing.Point(152, 36)
        Me.rad11.Name = "rad11"
        Me.rad11.Size = New System.Drawing.Size(41, 25)
        Me.rad11.TabIndex = 15
        Me.rad11.TabStop = True
        Me.rad11.Text = "1"
        Me.rad11.UseVisualStyleBackColor = True
        '
        'rad13
        '
        Me.rad13.AutoSize = True
        Me.rad13.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad13.Location = New System.Drawing.Point(300, 36)
        Me.rad13.Name = "rad13"
        Me.rad13.Size = New System.Drawing.Size(41, 25)
        Me.rad13.TabIndex = 17
        Me.rad13.TabStop = True
        Me.rad13.Text = "3"
        Me.rad13.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rad20)
        Me.GroupBox4.Controls.Add(Me.rad19)
        Me.GroupBox4.Controls.Add(Me.rad17)
        Me.GroupBox4.Controls.Add(Me.rad16)
        Me.GroupBox4.Controls.Add(Me.rad18)
        Me.GroupBox4.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(102, 417)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "4. Friendly"
        '
        'rad20
        '
        Me.rad20.AutoSize = True
        Me.rad20.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad20.Location = New System.Drawing.Point(438, 36)
        Me.rad20.Name = "rad20"
        Me.rad20.Size = New System.Drawing.Size(41, 25)
        Me.rad20.TabIndex = 19
        Me.rad20.TabStop = True
        Me.rad20.Text = "5"
        Me.rad20.UseVisualStyleBackColor = True
        '
        'rad19
        '
        Me.rad19.AutoSize = True
        Me.rad19.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad19.Location = New System.Drawing.Point(370, 36)
        Me.rad19.Name = "rad19"
        Me.rad19.Size = New System.Drawing.Size(41, 25)
        Me.rad19.TabIndex = 18
        Me.rad19.TabStop = True
        Me.rad19.Text = "4"
        Me.rad19.UseVisualStyleBackColor = True
        '
        'rad17
        '
        Me.rad17.AutoSize = True
        Me.rad17.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad17.Location = New System.Drawing.Point(230, 36)
        Me.rad17.Name = "rad17"
        Me.rad17.Size = New System.Drawing.Size(41, 25)
        Me.rad17.TabIndex = 16
        Me.rad17.TabStop = True
        Me.rad17.Text = "2"
        Me.rad17.UseVisualStyleBackColor = True
        '
        'rad16
        '
        Me.rad16.AutoSize = True
        Me.rad16.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad16.Location = New System.Drawing.Point(152, 36)
        Me.rad16.Name = "rad16"
        Me.rad16.Size = New System.Drawing.Size(41, 25)
        Me.rad16.TabIndex = 15
        Me.rad16.TabStop = True
        Me.rad16.Text = "1"
        Me.rad16.UseVisualStyleBackColor = True
        '
        'rad18
        '
        Me.rad18.AutoSize = True
        Me.rad18.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad18.Location = New System.Drawing.Point(300, 36)
        Me.rad18.Name = "rad18"
        Me.rad18.Size = New System.Drawing.Size(41, 25)
        Me.rad18.TabIndex = 17
        Me.rad18.TabStop = True
        Me.rad18.Text = "3"
        Me.rad18.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.rad25)
        Me.GroupBox5.Controls.Add(Me.rad23)
        Me.GroupBox5.Controls.Add(Me.rad21)
        Me.GroupBox5.Controls.Add(Me.rad22)
        Me.GroupBox5.Controls.Add(Me.rad24)
        Me.GroupBox5.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(102, 486)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "5. Good Communication"
        '
        'rad25
        '
        Me.rad25.AutoSize = True
        Me.rad25.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad25.Location = New System.Drawing.Point(438, 36)
        Me.rad25.Name = "rad25"
        Me.rad25.Size = New System.Drawing.Size(41, 25)
        Me.rad25.TabIndex = 19
        Me.rad25.TabStop = True
        Me.rad25.Text = "5"
        Me.rad25.UseVisualStyleBackColor = True
        '
        'rad23
        '
        Me.rad23.AutoSize = True
        Me.rad23.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad23.Location = New System.Drawing.Point(300, 36)
        Me.rad23.Name = "rad23"
        Me.rad23.Size = New System.Drawing.Size(41, 25)
        Me.rad23.TabIndex = 17
        Me.rad23.TabStop = True
        Me.rad23.Text = "3"
        Me.rad23.UseVisualStyleBackColor = True
        '
        'rad21
        '
        Me.rad21.AutoSize = True
        Me.rad21.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad21.Location = New System.Drawing.Point(152, 36)
        Me.rad21.Name = "rad21"
        Me.rad21.Size = New System.Drawing.Size(41, 25)
        Me.rad21.TabIndex = 15
        Me.rad21.TabStop = True
        Me.rad21.Text = "1"
        Me.rad21.UseVisualStyleBackColor = True
        '
        'rad22
        '
        Me.rad22.AutoSize = True
        Me.rad22.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad22.Location = New System.Drawing.Point(230, 36)
        Me.rad22.Name = "rad22"
        Me.rad22.Size = New System.Drawing.Size(41, 25)
        Me.rad22.TabIndex = 16
        Me.rad22.TabStop = True
        Me.rad22.Text = "2"
        Me.rad22.UseVisualStyleBackColor = True
        '
        'rad24
        '
        Me.rad24.AutoSize = True
        Me.rad24.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad24.Location = New System.Drawing.Point(370, 36)
        Me.rad24.Name = "rad24"
        Me.rad24.Size = New System.Drawing.Size(41, 25)
        Me.rad24.TabIndex = 18
        Me.rad24.TabStop = True
        Me.rad24.Text = "4"
        Me.rad24.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rad30)
        Me.GroupBox6.Controls.Add(Me.rad29)
        Me.GroupBox6.Controls.Add(Me.rad26)
        Me.GroupBox6.Controls.Add(Me.rad28)
        Me.GroupBox6.Controls.Add(Me.rad27)
        Me.GroupBox6.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(102, 555)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "6. Organization Skills"
        '
        'rad30
        '
        Me.rad30.AutoSize = True
        Me.rad30.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad30.Location = New System.Drawing.Point(438, 36)
        Me.rad30.Name = "rad30"
        Me.rad30.Size = New System.Drawing.Size(41, 25)
        Me.rad30.TabIndex = 19
        Me.rad30.TabStop = True
        Me.rad30.Text = "5"
        Me.rad30.UseVisualStyleBackColor = True
        '
        'rad29
        '
        Me.rad29.AutoSize = True
        Me.rad29.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad29.Location = New System.Drawing.Point(370, 36)
        Me.rad29.Name = "rad29"
        Me.rad29.Size = New System.Drawing.Size(41, 25)
        Me.rad29.TabIndex = 18
        Me.rad29.TabStop = True
        Me.rad29.Text = "4"
        Me.rad29.UseVisualStyleBackColor = True
        '
        'rad26
        '
        Me.rad26.AutoSize = True
        Me.rad26.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad26.Location = New System.Drawing.Point(152, 36)
        Me.rad26.Name = "rad26"
        Me.rad26.Size = New System.Drawing.Size(41, 25)
        Me.rad26.TabIndex = 15
        Me.rad26.TabStop = True
        Me.rad26.Text = "1"
        Me.rad26.UseVisualStyleBackColor = True
        '
        'rad28
        '
        Me.rad28.AutoSize = True
        Me.rad28.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad28.Location = New System.Drawing.Point(300, 36)
        Me.rad28.Name = "rad28"
        Me.rad28.Size = New System.Drawing.Size(41, 25)
        Me.rad28.TabIndex = 17
        Me.rad28.TabStop = True
        Me.rad28.Text = "3"
        Me.rad28.UseVisualStyleBackColor = True
        '
        'rad27
        '
        Me.rad27.AutoSize = True
        Me.rad27.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad27.Location = New System.Drawing.Point(230, 36)
        Me.rad27.Name = "rad27"
        Me.rad27.Size = New System.Drawing.Size(41, 25)
        Me.rad27.TabIndex = 16
        Me.rad27.TabStop = True
        Me.rad27.Text = "2"
        Me.rad27.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.rad35)
        Me.GroupBox7.Controls.Add(Me.rad34)
        Me.GroupBox7.Controls.Add(Me.rad31)
        Me.GroupBox7.Controls.Add(Me.rad33)
        Me.GroupBox7.Controls.Add(Me.rad32)
        Me.GroupBox7.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(102, 624)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "7. Excellent Preparation"
        '
        'rad35
        '
        Me.rad35.AutoSize = True
        Me.rad35.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad35.Location = New System.Drawing.Point(438, 36)
        Me.rad35.Name = "rad35"
        Me.rad35.Size = New System.Drawing.Size(41, 25)
        Me.rad35.TabIndex = 19
        Me.rad35.TabStop = True
        Me.rad35.Text = "5"
        Me.rad35.UseVisualStyleBackColor = True
        '
        'rad34
        '
        Me.rad34.AutoSize = True
        Me.rad34.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad34.Location = New System.Drawing.Point(370, 36)
        Me.rad34.Name = "rad34"
        Me.rad34.Size = New System.Drawing.Size(41, 25)
        Me.rad34.TabIndex = 18
        Me.rad34.TabStop = True
        Me.rad34.Text = "4"
        Me.rad34.UseVisualStyleBackColor = True
        '
        'rad31
        '
        Me.rad31.AutoSize = True
        Me.rad31.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad31.Location = New System.Drawing.Point(152, 36)
        Me.rad31.Name = "rad31"
        Me.rad31.Size = New System.Drawing.Size(41, 25)
        Me.rad31.TabIndex = 15
        Me.rad31.TabStop = True
        Me.rad31.Text = "1"
        Me.rad31.UseVisualStyleBackColor = True
        '
        'rad33
        '
        Me.rad33.AutoSize = True
        Me.rad33.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad33.Location = New System.Drawing.Point(300, 36)
        Me.rad33.Name = "rad33"
        Me.rad33.Size = New System.Drawing.Size(41, 25)
        Me.rad33.TabIndex = 17
        Me.rad33.TabStop = True
        Me.rad33.Text = "3"
        Me.rad33.UseVisualStyleBackColor = True
        '
        'rad32
        '
        Me.rad32.AutoSize = True
        Me.rad32.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad32.Location = New System.Drawing.Point(230, 36)
        Me.rad32.Name = "rad32"
        Me.rad32.Size = New System.Drawing.Size(41, 25)
        Me.rad32.TabIndex = 16
        Me.rad32.TabStop = True
        Me.rad32.Text = "2"
        Me.rad32.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.rad40)
        Me.GroupBox8.Controls.Add(Me.rad38)
        Me.GroupBox8.Controls.Add(Me.rad39)
        Me.GroupBox8.Controls.Add(Me.rad36)
        Me.GroupBox8.Controls.Add(Me.rad37)
        Me.GroupBox8.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(102, 693)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(533, 63)
        Me.GroupBox8.TabIndex = 7
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "8. Deep Knowledge And Passion"
        '
        'rad40
        '
        Me.rad40.AutoSize = True
        Me.rad40.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad40.Location = New System.Drawing.Point(438, 36)
        Me.rad40.Name = "rad40"
        Me.rad40.Size = New System.Drawing.Size(41, 25)
        Me.rad40.TabIndex = 19
        Me.rad40.TabStop = True
        Me.rad40.Text = "5"
        Me.rad40.UseVisualStyleBackColor = True
        '
        'rad38
        '
        Me.rad38.AutoSize = True
        Me.rad38.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad38.Location = New System.Drawing.Point(300, 36)
        Me.rad38.Name = "rad38"
        Me.rad38.Size = New System.Drawing.Size(41, 25)
        Me.rad38.TabIndex = 17
        Me.rad38.TabStop = True
        Me.rad38.Text = "3"
        Me.rad38.UseVisualStyleBackColor = True
        '
        'rad39
        '
        Me.rad39.AutoSize = True
        Me.rad39.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad39.Location = New System.Drawing.Point(370, 36)
        Me.rad39.Name = "rad39"
        Me.rad39.Size = New System.Drawing.Size(41, 25)
        Me.rad39.TabIndex = 18
        Me.rad39.TabStop = True
        Me.rad39.Text = "4"
        Me.rad39.UseVisualStyleBackColor = True
        '
        'rad36
        '
        Me.rad36.AutoSize = True
        Me.rad36.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad36.Location = New System.Drawing.Point(152, 36)
        Me.rad36.Name = "rad36"
        Me.rad36.Size = New System.Drawing.Size(41, 25)
        Me.rad36.TabIndex = 15
        Me.rad36.TabStop = True
        Me.rad36.Text = "1"
        Me.rad36.UseVisualStyleBackColor = True
        '
        'rad37
        '
        Me.rad37.AutoSize = True
        Me.rad37.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad37.Location = New System.Drawing.Point(230, 36)
        Me.rad37.Name = "rad37"
        Me.rad37.Size = New System.Drawing.Size(41, 25)
        Me.rad37.TabIndex = 16
        Me.rad37.TabStop = True
        Me.rad37.Text = "2"
        Me.rad37.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(209, 790)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(107, 50)
        Me.btnSubmit.TabIndex = 8
        Me.btnSubmit.Text = "SUBMIT"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("MV Boli", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(401, 790)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(107, 50)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.lblLecturerID)
        Me.GroupBox9.Controls.Add(Me.lblCourseID)
        Me.GroupBox9.Controls.Add(Me.cboCourseName)
        Me.GroupBox9.Controls.Add(Me.Label3)
        Me.GroupBox9.Controls.Add(Me.Label2)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(102, 12)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(502, 179)
        Me.GroupBox9.TabIndex = 10
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Course Details:"
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 870)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form5"
        Me.Text = "Course Evaluation System"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cboCourseName As ComboBox
    Friend WithEvents lblCourseID As Label
    Friend WithEvents lblLecturerID As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents rad1 As RadioButton
    Friend WithEvents rad2 As RadioButton
    Friend WithEvents rad5 As RadioButton
    Friend WithEvents rad3 As RadioButton
    Friend WithEvents rad4 As RadioButton
    Friend WithEvents rad10 As RadioButton
    Friend WithEvents rad7 As RadioButton
    Friend WithEvents rad8 As RadioButton
    Friend WithEvents rad9 As RadioButton
    Friend WithEvents rad6 As RadioButton
    Friend WithEvents rad15 As RadioButton
    Friend WithEvents rad14 As RadioButton
    Friend WithEvents rad12 As RadioButton
    Friend WithEvents rad11 As RadioButton
    Friend WithEvents rad13 As RadioButton
    Friend WithEvents rad20 As RadioButton
    Friend WithEvents rad19 As RadioButton
    Friend WithEvents rad17 As RadioButton
    Friend WithEvents rad16 As RadioButton
    Friend WithEvents rad18 As RadioButton
    Friend WithEvents rad25 As RadioButton
    Friend WithEvents rad23 As RadioButton
    Friend WithEvents rad21 As RadioButton
    Friend WithEvents rad22 As RadioButton
    Friend WithEvents rad24 As RadioButton
    Friend WithEvents rad30 As RadioButton
    Friend WithEvents rad29 As RadioButton
    Friend WithEvents rad26 As RadioButton
    Friend WithEvents rad28 As RadioButton
    Friend WithEvents rad27 As RadioButton
    Friend WithEvents rad35 As RadioButton
    Friend WithEvents rad34 As RadioButton
    Friend WithEvents rad31 As RadioButton
    Friend WithEvents rad33 As RadioButton
    Friend WithEvents rad32 As RadioButton
    Friend WithEvents rad40 As RadioButton
    Friend WithEvents rad38 As RadioButton
    Friend WithEvents rad39 As RadioButton
    Friend WithEvents rad36 As RadioButton
    Friend WithEvents rad37 As RadioButton
    Friend WithEvents GroupBox9 As GroupBox
End Class
