﻿Public Class Form1
    Private Sub CourseProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourseProfileToolStripMenuItem.Click
        Dim Form2 As New Form2
        Form2.Show()
    End Sub

    Private Sub LecturerProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LecturerProfileToolStripMenuItem.Click
        Dim Form3 As New Form3
        Form3.Show()
    End Sub

    Private Sub MarksReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MarksReportToolStripMenuItem.Click
        Dim Form6 As New Form6
        Form6.Show()
    End Sub

    Private Sub CourseReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourseReportToolStripMenuItem.Click
        Dim Form7 As New Form7
        Form7.Show()
    End Sub

    Private Sub LecturerReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LecturerReportToolStripMenuItem.Click
        Dim Form8 As New Form8
        Form8.Show()
    End Sub



    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim Form9 As New Form9
        Form9.Show()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Application.Exit()

    End Sub
End Class
