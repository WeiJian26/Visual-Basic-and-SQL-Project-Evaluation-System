﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarksReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ProfileDataToolStripMenuItem, Me.ShowReportToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(703, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogOutToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(46, 24)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.LogOutToolStripMenuItem.Text = "&Exit"
        '
        'ProfileDataToolStripMenuItem
        '
        Me.ProfileDataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourseProfileToolStripMenuItem, Me.LecturerProfileToolStripMenuItem})
        Me.ProfileDataToolStripMenuItem.Name = "ProfileDataToolStripMenuItem"
        Me.ProfileDataToolStripMenuItem.Size = New System.Drawing.Size(102, 26)
        Me.ProfileDataToolStripMenuItem.Text = "&Profile Data"
        '
        'CourseProfileToolStripMenuItem
        '
        Me.CourseProfileToolStripMenuItem.Name = "CourseProfileToolStripMenuItem"
        Me.CourseProfileToolStripMenuItem.Size = New System.Drawing.Size(192, 26)
        Me.CourseProfileToolStripMenuItem.Text = "&Course Profile"
        '
        'LecturerProfileToolStripMenuItem
        '
        Me.LecturerProfileToolStripMenuItem.Name = "LecturerProfileToolStripMenuItem"
        Me.LecturerProfileToolStripMenuItem.Size = New System.Drawing.Size(192, 26)
        Me.LecturerProfileToolStripMenuItem.Text = "&Lecturer Profile"
        '
        'ShowReportToolStripMenuItem
        '
        Me.ShowReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MarksReportToolStripMenuItem, Me.CourseReportToolStripMenuItem, Me.LecturerReportToolStripMenuItem})
        Me.ShowReportToolStripMenuItem.Name = "ShowReportToolStripMenuItem"
        Me.ShowReportToolStripMenuItem.Size = New System.Drawing.Size(108, 26)
        Me.ShowReportToolStripMenuItem.Text = "&Show Report"
        '
        'MarksReportToolStripMenuItem
        '
        Me.MarksReportToolStripMenuItem.Name = "MarksReportToolStripMenuItem"
        Me.MarksReportToolStripMenuItem.Size = New System.Drawing.Size(194, 26)
        Me.MarksReportToolStripMenuItem.Text = "&Marks Report"
        '
        'CourseReportToolStripMenuItem
        '
        Me.CourseReportToolStripMenuItem.Name = "CourseReportToolStripMenuItem"
        Me.CourseReportToolStripMenuItem.Size = New System.Drawing.Size(194, 26)
        Me.CourseReportToolStripMenuItem.Text = "&Course Report"
        '
        'LecturerReportToolStripMenuItem
        '
        Me.LecturerReportToolStripMenuItem.Name = "LecturerReportToolStripMenuItem"
        Me.LecturerReportToolStripMenuItem.Size = New System.Drawing.Size(194, 26)
        Me.LecturerReportToolStripMenuItem.Text = "&Lecturer Report"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(55, 26)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(133, 26)
        Me.AboutToolStripMenuItem.Text = "&About"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Assignment.My.Resources.Resources.help_logo
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(703, 473)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Course Evaluation System"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProfileDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseProfileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerProfileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShowReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MarksReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
End Class
