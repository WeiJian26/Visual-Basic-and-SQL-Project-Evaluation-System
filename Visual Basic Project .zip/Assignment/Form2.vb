﻿Imports System.Data.OleDb
Public Class Form2
    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDatabaseTable()
    End Sub
    Private Sub loadDatabaseTable()
        Using cn As New OleDbConnection(connectionString) 'establish database connection
            Using cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
                cmd.CommandText = "SELECT* FROM CourseTable;" 'giving SQL Command
                Dim dt As New DataTable With {.TableName = "CourseTable"} 'create new table in Visual Studio

                Try
                    cn.Open()
                    Dim ds As New DataSet
                    Dim assignmentTable As New DataTable With {.TableName = "CourseTable"}
                    ds.Tables.Add(assignmentTable)
                    ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, assignmentTable)
                    DataGridView1.DataSource = ds.Tables("CourseTable")
                    'DataGridView1.Columns("courseID").Visible = False

                    cn.Close()

                Catch ex As Exception

                    'very common for a developer to simply ignore errors,unwise

                End Try

            End Using
        End Using
    End Sub


    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim cn As New OleDbConnection(ConnectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
        cmd.CommandText = "SELECT* FROM CourseTable WHERE courseID=?;" 'giving SQL Command

        Try
            cmd.Parameters.AddWithValue("?", txtCourseID.Text)
            cn.Open()

            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader

            If dr.Read Then
                txtCourseName.Text = dr.Item("courseName")
                txtLecturerName.Text = dr.Item("lecturerName")
                txtLecturerID.Text = dr.Item("lecturerID")
                txtCourseID.Text = dr.Item("courseID")
            Else
                MessageBox.Show("Invalid course ID")
            End If
            cn.Close()
        Catch ex As Exception
            'very common for a developer to simply ignore errors,unwise
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "INSERT INTO CourseTable(courseID,courseName,lecturerID,lecturerName)VALUES(?,?,?,?)"
                cmd.Parameters.AddWithValue("?", txtCourseID.Text)
                cmd.Parameters.AddWithValue("?", txtCourseName.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerID.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerName.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")

                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "UPDATE CourseTable SET courseName=?,lecturerName=? WHERE courseID=?"
                cmd.Parameters.AddWithValue("?", txtCourseName.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerID.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerName.Text)
                cmd.Parameters.AddWithValue("?", txtCourseID.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception


                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "DELETE FROM CourseTable WHERE courseID=?"
                cmd.Parameters.AddWithValue("?", txtCourseID.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")

                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub
End Class