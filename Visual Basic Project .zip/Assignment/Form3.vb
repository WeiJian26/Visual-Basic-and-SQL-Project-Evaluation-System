﻿Imports System.Data.OleDb
Public Class Form3
    Dim ConnectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\qing_\OneDrive\Desktop\Assignment.accdb"
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDatabaseTable()
    End Sub
    Private Sub loadDatabaseTable()
        Using cn As New OleDbConnection(connectionString) 'establish database connection
            Using cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
                cmd.CommandText = "SELECT* FROM LecturerTable;" 'giving SQL Command
                Dim dt As New DataTable With {.TableName = "LecturerTable"} 'create new table in Visual Studio

                Try
                    cn.Open()
                    Dim ds As New DataSet
                    Dim assignmentTable As New DataTable With {.TableName = "LecturerTable"}
                    ds.Tables.Add(assignmentTable)
                    ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, assignmentTable)
                    DataGridView2.DataSource = ds.Tables("LecturerTable")
                    'DataGridView2.Columns("lecturerID").Visible = False

                    cn.Close()

                Catch ex As Exception

                    'very common for a developer to simply ignore errors,unwise

                End Try

            End Using
        End Using
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Using cn As New OleDbConnection(ConnectionString) 'establish database connection
            Using cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object
                cmd.CommandText = "SELECT* FROM LecturerTable;" 'giving SQL Command
                Dim dt As New DataTable With {.TableName = "LecturerTable"} 'create new table in Visual Studio

                Try
                    cn.Open()
                    Dim ds As New DataSet
                    Dim assignmentTable As New DataTable With {.TableName = "LecturerTable"}
                    ds.Tables.Add(assignmentTable)
                    ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, assignmentTable)
                    DataGridView2.DataSource = ds.Tables("LecturerTable")
                    'DataGridView2.Columns("courseID").Visible = False

                    cn.Close()

                Catch ex As Exception

                    'very common for a developer to simply ignore errors,unwise

                End Try

            End Using
        End Using
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "INSERT INTO LecturerTable(lecturerID,lecturerName)VALUES(?,?)"
                cmd.Parameters.AddWithValue("?", txtLecturerID.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerName.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")

                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "UPDATE LecturerTable SET lecturerName=? WHERE lecturerID=?"
                cmd.Parameters.AddWithValue("?", txtLecturerName.Text)
                cmd.Parameters.AddWithValue("?", txtLecturerID.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception


                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Using cn As New OleDbConnection(ConnectionString)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "DELETE FROM LecturerTable WHERE lecturerID=?"
                cmd.Parameters.AddWithValue("?", txtLecturerID.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")

                End Try
                loadDatabaseTable()
            End Using
        End Using
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class